<html>

<body background="undisputed4.jpg">
<form action="checking.php" method="post">
<table bgcolor="skyblue" border="2px">

<thead><h2>Enter Details</h2></thead>

<tr><td>Database Name : </td><td><input type="text" name="dbnme"></td></tr>
<tr><td>Table Name : </td><td><input type="text" name="tablenme"></td></tr>

<tr><td><input type="submit" value="create"></td></tr>
</table>
</form>
</body>
</html>


<?php

?>