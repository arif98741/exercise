<?php include "functions.php" ?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>PHP CRUD by MYSQLi</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="main">
		<div class="header">
			<h1>PHP CRUD by MYSQLi</h1>
			<p>Learn and Enjoy</p>
			<nav>
				<ul>
					<li><a href="">Home</a></li>
				</ul>
			</nav>
		</div><hr>
		