<!DOCTYPE html>
<html lang="en" >
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>HTML To PDF Generator</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>
        <div>
            <div class="row">
                <div class="col-xs-12 col-md-8">



                </div>
                <div class="col-xs-6 col-md-4"></div>
            </div>

        </div>


        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>